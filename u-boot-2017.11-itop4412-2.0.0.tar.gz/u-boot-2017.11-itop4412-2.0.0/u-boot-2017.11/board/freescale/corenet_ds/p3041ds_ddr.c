/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0
 */

#include <common.h>
#include <fsl_ddr_sdram.h>

fixed_ddr_parm_t fixed_ddr_parm_0[] = {
	{0, 0, NULL}
};
