/*
 * Copyright (C) 2003 Ralf Baechle
 *
 * SPDX-License-Identifier:	GPL-2.0
 */
#ifndef __ASM_MACH_GENERIC_CPU_FEATURE_OVERRIDES_H
#define __ASM_MACH_GENERIC_CPU_FEATURE_OVERRIDES_H

/* Intentionally empty file ...	 */

#endif /* __ASM_MACH_GENERIC_CPU_FEATURE_OVERRIDES_H */
